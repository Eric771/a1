# -*- coding: utf-8 -*-
from akad.ttypes import ApplicationType
import re

class Config():
    LINE_HOST_DOMAIN            = 'https://legy-jp.line.naver.jp'
    LINE_LOGIN_QUERY_PATH       = '/api/v4p/rs'
    LINE_AUTH_QUERY_PATH        = '/api/v4/TalkService.do'
    LINE_API_QUERY_PATH_FIR     = '/S4'
    LINE_POLL_QUERY_PATH_FIR    = '/P4'
    LINE_CERTIFICATE_PATH       = '/Q'
    LINE_FASTER_R        = ["ub1a7b63155625df4c3703b667dae4eab"]

    EMAIL_REGEX = re.compile(r"[^@]+@[^@]+\.[^@]+")

    def __init__(self):
        self.APP_NAME = 'IOS\t8.16.2\tIphone X\t8.1.0'